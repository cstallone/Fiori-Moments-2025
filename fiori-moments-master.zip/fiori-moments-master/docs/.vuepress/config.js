module.exports = {
  head: [
    ['script', { src: 'vendor.min.js' }],
    ['script', { src: 'guidebook.js' }]
  ],
  title: 'UX Illustrations for SAP Fiori',
  description: '',
  base: '/sap-design-ops/fiori-moments/',
  themeConfig: {
    sidebar: 'auto',
    logo: '/logo-sap-fiori-moments.svg',
    repo: 'https://github.tools.sap/sap-design-ops/fiori-moments',
    nav: [
      { text: 'Introduction', link: '/' },
      { text: 'Voice & Tone', link: '/voice-tone.html' },
      { text: 'Empty States', link: '/empty-states.html' },
      { text: 'Success States', link: '/success-states.html' },
      { text: 'About Illustrations', link: '/illustrations.html' },
      { text: 'All Illustrations', link: '/all-illustrations.html' },
      { text: 'Resources', link: '/resources.html' },
      { text: 'Component Status', link: '/status.html'},
      { text: 'Contact Us', link: '/contact.html' }
    ]
  },
  sidebar: "auto",
  scss: {
  },
  markdown: {
    anchor: {
      level: [2],
      permalinkBefore: false,
      permalinkClass: 'anchor'
    }
  }
}
