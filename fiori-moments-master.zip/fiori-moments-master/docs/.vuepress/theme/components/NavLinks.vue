<template>
  <nav
    id="page-nav"
    class="nav flex-column nav-vertical-2"
    v-if="userLinks.length || repoLink"
  >
    <!-- user links -->
    <div
      class="nav-item"
      v-for="item in userLinks"
      :key="item.link"
    >
      <DropdownLink
        v-if="item.type === 'links'"
        :item="item"
      />
      <NavLink
        v-else
        :item="item"
      />
    </div>
    <!-- Sketch design kit -->
    <a class="sketch-link" target="_blank" rel="noopener noreferrer" href="https://sap.sharepoint.com/:u:/r/teams/FioriBrandExperienceSystem/Shared%20Documents/General/Public/Sketch%20Design%20Kit/Fiori_Moments_V1.0.0.sketch?csf=1&web=1&e=qoxef3"><img src="../../public/SketchLogo@2x.png" width="20"/>&nbsp;
    <span>Sketch Design Kit v1.0.0 </span>&nbsp; <svg width="15px" height="15px" viewBox="0 0 15 15" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <!-- Generator: Sketch 64 (93537) - https://sketch.com -->
    <title>Artboard</title>
    <desc>Created with Sketch.</desc>
    <g id="Artboard" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="round">
        <g id="Group-5" transform="translate(2.000000, 1.000000)" stroke="#AAAAAA" stroke-width="1.5">
            <g id="Group-2">
                <line x1="1.5" y1="4.5" x2="10" y2="4.5" id="Path" stroke-linejoin="round" transform="translate(5.500000, 4.500000) rotate(90.000000) translate(-5.500000, -4.500000) "></line>
                <line x1="0.5" y1="12.5" x2="10.5" y2="12.5" id="Path"></line>
            </g>
            <polyline id="Path-2" stroke-linejoin="round" points="10.0244661 5 5.5 9.92841238 1.03423684 5"></polyline>
        </g>
    </g>
</svg>
</a>
    
    <!-- repo link -->
    <a
      v-if="repoLink"
      :href="repoLink"
      class="repo-link"
      target="_blank"
      rel="noopener noreferrer"
    >
    <span class="icon-github"></span>&nbsp;
    <span> {{ repoLabel }}</span>&nbsp;
    <span> v1.0.0 </span>&nbsp; <OutboundLink/>
    <svg width="15px" height="15px" viewBox="0 0 15 15" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <!-- Generator: Sketch 64 (93537) - https://sketch.com -->
    <title>Artboard</title>
    <desc>Created with Sketch.</desc>
    <g id="Artboard" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="round">
        <polyline id="Path" stroke="#AAAAAA" stroke-width="1.5" points="12.5 8.07907371 12.5 13.5 2 13.5 2 3 7.08221878 3"></polyline>
        <g id="Group-6" transform="translate(8.000000, 2.000000)" stroke="#AAAAAA" stroke-width="1.5">
            <line x1="-5.68434189e-14" y1="4.94238752" x2="5.06147191" y2="0" id="Path-3"></line>
            <polyline id="Path-4" points="5.06147191 2.79 5.06147191 4.36539693e-13 2.27207526 4.36539693e-13"></polyline>
        </g>
    </g>
</svg>
    </a>
  </nav>
</template>

<script>
import DropdownLink from '@theme/components/DropdownLink.vue'
import { resolveNavLinkItem } from '../util'
import NavLink from '@theme/components/NavLink.vue'
import { BBadge } from 'bootstrap-vue'

export default {
  components: { NavLink, DropdownLink, 'b-badge': BBadge },

  computed: {
    userNav () {
      return this.$themeLocaleConfig.nav || this.$site.themeConfig.nav || []
    },

    nav () {
      const { locales } = this.$site
      if (locales && Object.keys(locales).length > 1) {
        const currentLink = this.$page.path
        const routes = this.$router.options.routes
        const themeLocales = this.$site.themeConfig.locales || {}
        const languageDropdown = {
          text: this.$themeLocaleConfig.selectText || 'Languages',
          items: Object.keys(locales).map(path => {
            const locale = locales[path]
            const text = themeLocales[path] && themeLocales[path].label || locale.lang
            let link
            // Stay on the current page
            if (locale.lang === this.$lang) {
              link = currentLink
            } else {
              // Try to stay on the same page
              link = currentLink.replace(this.$localeConfig.path, path)
              // fallback to homepage
              if (!routes.some(route => route.path === link)) {
                link = path
              }
            }
            return { text, link }
          })
        }
        return [...this.userNav, languageDropdown]
      }
      return this.userNav
    },

    userLinks () {
      return (this.nav || []).map(link => {
        return Object.assign(resolveNavLinkItem(link), {
          items: (link.items || []).map(resolveNavLinkItem)
        })
      })
    },

    repoLink () {
      const { repo } = this.$site.themeConfig
      if (repo) {
        return /^https?:/.test(repo)
          ? repo
          : `https://github.com/${repo}`
      }
    },

    repoLabel () {
      if (!this.repoLink) return
      if (this.$site.themeConfig.repoLabel) {
        return this.$site.themeConfig.repoLabel
      }

      const repoHost = this.repoLink.match(/^https?:\/\/[^/]+/)[0]
      const platforms = ['GitHub', 'GitLab', 'Bitbucket']
      for (let i = 0; i < platforms.length; i++) {
        const platform = platforms[i]
        if (new RegExp(platform, 'i').test(repoHost)) {
          return platform
        }
      }

      return 'Source'
    }
  }
}
</script>

<style lang="stylus">


</style>
