<template>
	<div class="plainCards">  
	  <b-card class="mb-2">
		<h5>{{ this.title }}</h5>
	  	<b-card-text v-html="description"></b-card-text>
	  </b-card>
	</div>
</template>

<script>
import { BCard, BCardText, BTabs, BTab, CollapsePlugin, CardPlugin } from 'bootstrap-vue'; 
Vue.component('b-card', BCard);
import Vue from 'vue';

export default {
	components: {
	    'b-card': BCard,
	    'b-tabs': BTabs,
	    'b-tab': BTab,
	    'b-card-text': BCardText
    },
	props: {
		description: {
			type: String,
			default: "Lorem ipsum dolor"
		},
		title: String
	}
}
</script>

<style lang="scss">
.plainCards {
	margin-bottom: 20px;
  	i {
  		vertical-align:middle;
  		margin-right: 10px !important;
  	}
  	h5{
  		color: #555555 !important;
  		font-weight: normal;
  	}
}
</style>
