<template>
	  <div class="topic topic-vertical bordered">
	  	<span class="topic-label bg-scroll"></span>
    	<div class="text-article">
     		<p v-html="description"></p>
     	</div>
	</div>
</template>

<script>
export default {
	props: {
		description: {
			type: String,
			default: "Lorem ipsum dolor"
		}
	}
}
</script>
<style lang="scss">
	.bg-scroll{
	      background-color: #e5e5e5;
	    }
	.text-article {
		color: #767676;
	}
  
</style>

