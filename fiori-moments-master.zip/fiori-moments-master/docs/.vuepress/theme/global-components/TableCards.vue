<template>
<div class="tableCards">
  <b-card-group deck>
    <b-card img-top>
		<div class="border-bottom border-success green"><i class="icon-check2 mr-2 text-green fs-24"></i>Do</div>
		<br />
		<img class="block-image" :src="img1" :srcset="srcset1" width="385px" height="379px" :alt="alt1"/>
		<b-card-text v-html="description1"></b-card-text>
    </b-card>

    <b-card img-top>
    <div class="border-bottom border-success red"><svg width="30px" height="30px" viewBox="0 0 16 16" class="bi bi-x" fill="#e12626" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
</svg></i>Don't</div>
	    <br />
	    <img class="block-image" :src="img2" width="385px" height="379px" :srcset="srcset2"  :alt="alt2"/>
	    <b-card-text v-html="description2"></b-card-text>
    </b-card>
  </b-card-group>
</div>
</template>

<script>
import { BCard, BCardText, BCardGroup } from 'bootstrap-vue'; 
import Vue from 'vue';


export default {
  components: {
    'b-card': BCard,
    'b-card-text': BCardText,
    'b-card-group': BCardGroup
  },
	props: {
		pic: {
		 type: String,
		 default: "Lorem ipsum dolor"
		},
		alt1: String,
		alt2: String,
		img1: String,
	    img2: String,
	    src: String,
		description1: {
	      type: String,
	      default: "Lorem ipsum dolor"
	    },
	    description2: {
	      type: String,
	      default: "Lorem ipsum dolor"
	    }
	},
	computed: {
	     srcset1 () {
	      return `${this.img1}`
	    },
	    srcset2 () {
	      return `${this.img2}`
	    }
	},
	methods: {
	    
	},
  mounted(){
      if(window.location.hash === '#use-case-library'){ 
        document.querySelector('#use-case-library').scrollIntoView({ 
          behavior: 'smooth' 
        });
      }
    // Scroll to a certain element
  
    //if(window.location.hash){ 
      // smooth scroll to the anchor id 
      //$('html,body').animate({ scrollTop:$(window.location.hash).offset().top + 'px' },1000,'swing'); }; 
  }
}
</script>
<style lang="scss">
.tableCards {
  .card {
    background-color: transparent;
    box-shadow: none;
    border: 0;
  }
  .card-body{
  padding: 0px;
  }
  .border-success.green {
  	border-bottom: 5px solid #28a745 !important;
  	padding-bottom: 10px;
  	font-weight: bold;
  }
  .border-success.red {
  	border-bottom: 5px solid #dc3545 !important;
  	padding-bottom: 5px;
  	font-weight: bold;
  }
  .border-bottom.border-success {
  	i {
  		vertical-align:middle;
  		margin-right: 10px !important;
  	}
  }
}
ul {
  padding-left: 20px;
  margin:0
  }
img {
    height: auto;
  }
</style>

