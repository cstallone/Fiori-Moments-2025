<template>
  <div>
    <img class="block-image" :src="x2" :srcset="srcset" :alt="alt"/>
  </div>
</template>

<script>
export default {
  props: {
    x1: String,
    x2: String,
    alt: String,
    src: String
  },
  computed: {
    srcset () {
      return `${this.x2} 2x`
    }
  }
}
</script>

<style>

</style>
