<template>
<div class="tableCards">
  <b-card-group deck>
    <b-card img-top>
		<img class="block-image" :src="img1" :srcset="srcset1" width="385px" height="379px" :alt="alt1"/>
		<b-card-text v-html="description1"></b-card-text>
    </b-card>

    <b-card img-top>
	    <img class="block-image" :src="img2" :srcset="srcset2" width="385px" height="379px" :alt="alt2"/>
	    <client-only><b-card-text v-html="description2"></b-card-text></client-only>
    </b-card>
    
      <b-card img-top v-if="addCard === '3'">
        <img class="block-image" :src="img3" :srcset="srcset3" width="385px" height="379px" :alt="alt3"/>
        <b-card-text v-html="description3"></b-card-text>
      </b-card>
  </b-card-group>
</div>
</template>

<script>
import { BCard, BCardText, BCardGroup } from 'bootstrap-vue'; 
import Vue from 'vue';


export default {
  components: {
    'b-card': BCard,
    'b-card-text': BCardText,
    'b-card-group': BCardGroup
  },
	props: {
		pic: {
		 type: String,
		 default: "Lorem ipsum dolor"
		},
		alt1: String,
		alt2: String,
    alt3: String,
		img1: String,
	  img2: String,
    img3: String,
	  src: String,
    addCard: String,
		description1: {
	      type: String,
	    },
   description2: {
      type: String,
    },
    description3: {
      type: String,
    }
	},
	computed: {
	     srcset1 () {
	      return `${this.img1}`
	    },
	    srcset2 () {
	      return `${this.img2}`
	    },
      srcset3 () {
        return `${this.img3}`
      }
	},
  name: 'app',
    currentTab: 'tab1',
    isHidden: true,
   methods: {
    handleClick(newTab) {
      this.currentTab = newTab;
    },
  }
}
</script>
<style>
  img {
    height: auto;
  } 
</style>