<template>
<div role="tablist" class="accordion accordion-boxed">
    <b-card no-body class="mb-1">
      <b-card-header role="tab" >
        <b-button block v-b-toggle="accordionId" variant="link">{{ this.title }}</b-button>
      </b-card-header>
      <b-collapse v-bind:id="accordionId" accordion="my-accordion" role="tabpanel">
        <b-card-body>
          <b-card-text>
            <div class="library-example">
              <b-card no-body>
               <b-card-text v-html="description"></b-card-text>
              </b-card>
            </div>
          </b-card-text>
        </b-card-body>
      </b-collapse>
    </b-card>
</div>
</template>

<script>
import { BCard, BCardText, BTabs, BTab, BButton, CollapsePlugin,CardPlugin, BFormSelect, FormSelectPlugin, BDropdown, DropdownPlugin } from 'bootstrap-vue'; 
import Vue from 'vue';
import Tabs from 'vue-tabs-with-active-line';
Vue.use(CollapsePlugin);
Vue.use(CardPlugin);
Vue.use(FormSelectPlugin);
Vue.use(DropdownPlugin);


export default {
  components: {
    'b-card': BCard,
    'b-tabs': BTabs,
    'b-tab': BTab,
    'b-card-text': BCardText,
    'tabs': Tabs,
    'b-button': BButton,
    'b-dropdown': BDropdown,
    'b-form-select': BFormSelect
  },
  props: {
    options: {
      type: Array,
      default() {
        return [];
      }
    },
    disabled: {
      type: Boolean,
      default: false
    },
    id: String,
    accordionId: String,
    title: String,
    type: String,
    description: String,
    },
  methods: {
    handleClick(newTab) {
      this.currentTab = newTab;
    }
  }
}

</script>


<style lang="scss">
.library-example {
  margin-top: 12px;
  .card {
    background-color: transparent;
    box-shadow: none;
    border: 0;
  }
  .card-header {
    padding: 0;
    background-color: transparent;
    border: none;
    margin-bottom: 24px;
  }
  .card-header-pills {
    margin-top: 0;
  }
  .card-body {
    background: rgb(255, 255, 255);
    padding-left: 0;
  }
  .nav-link {
    &.active {
      background-color: white;
    }
  }
  .app a {
    cursor: pointer;
    color: rgb(10, 110, 209);
    margin-bottom: 10px;
    font-size: 14px;
    display: block;
  }
  .language-markup{
    background: rgb(229, 229, 229);
    box-shadow: 0px 0px 15px 0px rgba(0, 0, 0, 0.05);
    border: 1px solid #e5e5e5;
    border-radius: 0.25rem;
    white-space: pre-line;
    padding: 20px !important;
  }
  .border-left{
    padding-left: 20px;
    margin-top: 20px
  }
  .custom-select {
   width:20%;
   height: 50px;
   width:110px;
  }
  ul {
  padding-left: 20px;
  margin:0
  }
}
  