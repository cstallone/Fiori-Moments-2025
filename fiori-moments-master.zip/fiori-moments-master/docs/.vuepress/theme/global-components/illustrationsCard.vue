<template>
  <div class="illustration">
    <b-card class="mb-2" align="center">
      <img class="block-image" :src="img" :srcset="srcset" :alt="alt"/>
      <h3 class="card-title mb-1">{{this.title}}</h3>
      <b-card-text v-html="description"></b-card-text>
    </b-card>
  </div>
</template>

<script>
import { BCard, BCardText, BTabs, BTab, BButton, CollapsePlugin, CardPlugin, BCardGroup } from 'bootstrap-vue'; 
Vue.component('b-card', BCard);

import Vue from 'vue';
import Tabs from 'vue-tabs-with-active-line';
Vue.use(CollapsePlugin);
Vue.use(CardPlugin);

export default {
  components: {
    'b-card': BCard,
    'b-tabs': BTabs,
    'b-tab': BTab,
    'b-card-text': BCardText,
    'tabs': Tabs,
    'b-button': BButton,
    'b-card-group': BCardGroup
  },
  props: {
    pic: {
     type: String,
     default: "Lorem ipsum dolor"
    },
    title: String,
    alt: String,
    img: String,
    src: String,
    hiddenText: String,
    description: {
        type: String,
        default: "Lorem ipsum dolor"
      }
  },
  computed: {
       srcset () {
        return `${this.img} 2x`
      }
  },
  mounted(){
    // Scroll to a certain element
    if(window.location.hash === '#creating-your-own-illustrations'){ 
      document.querySelector('#creating-your-own-illustrations').scrollIntoView({ 
        behavior: 'smooth' 
      });
    }
  }
}
</script>
<style lang="scss">
@media only screen and (min-width: 992px) {
  .illustration {
    .card-text{
      padding: 10px 175px;
    }
  }
}
</style>


