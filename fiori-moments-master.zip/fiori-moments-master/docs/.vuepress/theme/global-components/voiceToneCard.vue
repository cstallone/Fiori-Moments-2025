<template>
  <div class="voiceTone">
    <b-card class="mb-2" align="center">
      <img class="block-image" :src="img" :srcset="srcset" :alt="alt"/>
      <h3 class="card-title mb-1">{{this.title}}</h3>
      <b-card-text v-html="description"></b-card-text>

      <div class="app"> <!--Show/Hide button starts here-->
        <b-card-text v-if="!isHidden">
            {{ this.hiddenText }}
        </b-card-text>
        <a v-on:click="isHidden = !isHidden" class="mt-1 text-blue">{{ isHidden ? 'READ MORE' : 'READ LESS' }}</a>
      </div>
    </b-card>
  </div>
</template>

<script>
import { BCard, BCardText, BTabs, BTab, BButton, CollapsePlugin, CardPlugin, BCardGroup } from 'bootstrap-vue'; 
Vue.component('b-card', BCard);

import Vue from 'vue';
import Tabs from 'vue-tabs-with-active-line';
Vue.use(CollapsePlugin);
Vue.use(CardPlugin);

export default {
  components: {
    'b-card': BCard,
    'b-tabs': BTabs,
    'b-tab': BTab,
    'b-card-text': BCardText,
    'tabs': Tabs,
    'b-button': BButton,
    'b-card-group': BCardGroup
  },
  props: {
    pic: {
     type: String,
     default: "Lorem ipsum dolor"
    },
    title: String,
    alt: String,
    img: String,
    src: String,
    hiddenText: String,
    description: {
        type: String,
        default: "Lorem ipsum dolor"
      }
  },
  computed: {
       srcset () {
        return `${this.img} 2x`
      }
  },
  name: 'app',
   data: () => ({
    isHidden: true,
    visible: false
  }),
   methods: {
    
    },
}
</script>
<style lang="scss">
  .voiceTone {
    .card-text{
      padding: 10px 165px;
    }
   .text-blue{
      cursor: pointer;
      }
  }
</style>

