<template>
<section class="py-0">
          <!-- content -->
            <div class="justify-content-between doc-content-body">
              <b-card-group deck>
                <b-card>
                  <Moment :type="this.type" v-bind:id="this.id"/>
                  <template #footer>
                    <small class="text-muted">#sapIllus-Spot-{{id}}</small>
                  </template>
                </b-card>
                <b-card>
                  <Moment :type="this.typeDialog" :id="this.idDialog"/>
                  <template #footer>
                    <small class="text-muted">#sapIllus-Dialog-{{id}}</small>
                  </template>
                </b-card>
                <b-card>
                  <Moment :type="this.typeScene" :id="this.idScene"/>
                  <template #footer>
                    <small class="text-muted">#sapIllus-Scene-{{id}}</small>
                  </template>
                </b-card>
              </b-card-group>
          </div>
          <!-- / content -->
    </section>

</template>


<script>
import { BCard, BCardText, BTabs, BTab, BButton, CollapsePlugin,CardPlugin, BFormSelect, FormSelectPlugin, BDropdown, DropdownPlugin } from 'bootstrap-vue'; 
import Vue from 'vue';
import Tabs from 'vue-tabs-with-active-line';
import Home from '@theme/components/Home.vue';
import Navbar from '@theme/components/Navbar.vue';
import { resolveSidebarItems } from '../util';
Vue.use(CollapsePlugin);
Vue.use(CardPlugin);

export default {
  data () {
    return {
      isSidebarOpen: false
    }
  },

  computed: {
    shouldShowNavbar () {
      const { themeConfig } = this.$site
      const { frontmatter } = this.$page
      if (
        frontmatter.navbar === false
        || themeConfig.navbar === false) {
        return false
      }
      return (
        this.$title
        || themeConfig.logo
        || themeConfig.repo
        || themeConfig.nav
        || this.$themeLocaleConfig.nav
      )
    },

    shouldShowSidebar () {
      const { frontmatter } = this.$page
      return (
        !frontmatter.home
        && frontmatter.sidebar !== false
        && this.sidebarItems.length
      )
    },

    sidebarItems () {
      return resolveSidebarItems(
        this.$page,
        this.$page.regularPath,
        this.$site,
        this.$localePath
      )
    },

    pageClasses () {
      const userPageClass = this.$page.frontmatter.pageClass
      return [
        {
          'no-navbar': !this.shouldShowNavbar,
          'sidebar-open': this.isSidebarOpen,
          'no-sidebar': !this.shouldShowSidebar
        },
        userPageClass
      ]
    }
  },
  components: {
  Home, Navbar,
    'b-card': BCard,
    'b-tabs': BTabs,
    'b-tab': BTab,
    'b-card-text': BCardText,
    'tabs': Tabs,
    'b-button': BButton,
    'b-dropdown': BDropdown,
    'b-form-select': BFormSelect
  },
  props: {
    options: {
      type: Array,
      default() {
        return [];
      }
    },
    disabled: {
      type: Boolean,
      default: false
    },
    id: String,
    accordionId: String,
    title: String,
    type: String,
    idDialog: String,
    typeDialog: String,
    typeSpot: String,
    idSpot: String,
    typeScene: String,
    idScene: String,
    titletext: String,
    description: String,
    nospotsvg: String,
    noscenesvg: String,
    nodialogsvg: String,
    nosvg: String,
    nospotsvgcss: String,
    noscenecss: String,
    nodialogcss: String,
    message: {
      type: String,
      default: "test"
    },
    header: {
      type: String,
      default: "test"
    },
    isOptionDisabled: String,
    dialogOptionDisabled: String,
    sceneOptionDisabled: String,
    DropDown: String,
    messageSpot: String,
    headerSpot: String,
    headerSpot3: String,
    messageSpot3: String,
    headerDialog1: {
      type: String,
      default: ""
    },
    headerDialog2: {
      type: String,
      default: ""
    },
    headerDialog3: {
      type: String,
      default: ""
    },
    messageDialog1: {
      type: String,
      default: ""
    },
    messageDialog2: {
      type: String,
      default: ""
    },
    messageDialog3: {
      type: String,
      default: ""
    },
    headerScene1: {
      type: String,
      default: ""
    },
    headerScene2: {
      type: String,
      default: ""
    },
    headerScene3: {
      type: String,
      default: ""
    },
    messageScene1: {
      type: String,
      default: ""
    },
    messageScene2: {
      type: String,
      default: ""
    },
    messageScene3: {
      type: String,
      default: ""
    }
  },

  mounted () {
    this.$router.afterEach(() => {
      this.isSidebarOpen = false
    })
  },
  computed: {
    shouldShowNavbar () {
      const { themeConfig } = this.$site
      const { frontmatter } = this.$page
      if (
        frontmatter.navbar === false
        || themeConfig.navbar === false) {
        return false
      }
      return (
        this.$title
        || themeConfig.logo
        || themeConfig.repo
        || themeConfig.nav
        || this.$themeLocaleConfig.nav
      )
    },

    shouldShowSidebar () {
      const { frontmatter } = this.$page
      return (
        !frontmatter.home
        && frontmatter.sidebar !== false
        && this.sidebarItems.length
      )
    },

    sidebarItems () {
      return resolveSidebarItems(
        this.$page,
        this.$page.regularPath,
        this.$site,
        this.$localePath
      )
    },

    pageClasses () {
      const userPageClass = this.$page.frontmatter.pageClass
      return [
        {
          'no-navbar': !this.shouldShowNavbar,
          'sidebar-open': this.isSidebarOpen,
          'no-sidebar': !this.shouldShowSidebar
        },
        userPageClass
      ]
    },
    uppercaseType() {
      return this.type.charAt(0).toUpperCase() + this.type.slice(1);
    },
    uppercaseTypeDialog(){
      return this.typeDialog.charAt(0).toUpperCase() + this.typeDialog.slice(1);
    },
    uppercaseTypeScene(){
      return this.typeScene.charAt(0).toUpperCase() + this.typeScene.slice(1);
    }
  },
  name: 'app',
  methods: {
    handleClick(newTab) {
      this.currentTab = newTab;
     // console.log('this component is showing')
    },
    getMsg () {
      return msgs[Math.floor(Math.random() * msgs.length)]
    },
    toggleSidebar (to) {
      this.isSidebarOpen = typeof to === 'boolean' ? to : !this.isSidebarOpen
    },

    // side swipe
    onTouchStart (e) {
      this.touchStart = {
        x: e.changedTouches[0].clientX,
        y: e.changedTouches[0].clientY
      }
    },

    onTouchEnd (e) {
      const dx = e.changedTouches[0].clientX - this.touchStart.x
      const dy = e.changedTouches[0].clientY - this.touchStart.y
      if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 40) {
        if (dx > 0 && this.touchStart.x <= 80) {
          this.toggleSidebar(true)
        } else {
          this.toggleSidebar(false)
        }
      }
    }
  }
}
</script>
<style lang="scss">
/* contents of dist/sapIllus-Fills.css */
:root {
  --sapIllus_BrandColorPrimary: #0a6ed1;
  --sapIllus_BrandColorSecondary: #72b5f8;
  --sapIllus_StrokeDetailColor: #4a5055;
  --sapIllus_Layering1: #9da4aa;
  --sapIllus_Layering2: #c6cace;
  --sapIllus_BackgroundColor: #e7e9ea;
  --sapIllus_ObjectFillColor: #fff;
  --sapIllus_AccentColor: #ffba10;
  --sapIllus_NoColor: none;
  --sapIllus_PatternShadow: url(#sapIllus_PatternShadow);
  --sapIllus_PatternHighlight: url(#sapIllus_PatternHighlight);
}
.sapIllus_BrandColorPrimary {
  fill: var(--sapIllus_BrandColorPrimary);
}
.sapIllus_BrandColorSecondary {
  fill: var(--sapIllus_BrandColorSecondary);
}
.sapIllus_StrokeDetailColor {
  fill: var(--sapIllus_StrokeDetailColor);
}
.sapIllus_Layering1 {
  fill: var(--sapIllus_Layering1);
}
.sapIllus_Layering2 {
  fill: var(--sapIllus_Layering2);
}
.sapIllus_BackgroundColor {
  fill: var(--sapIllus_BackgroundColor);
}
.sapIllus_ObjectFillColor {
  fill: var(--sapIllus_ObjectFillColor);
}
.sapIllus_AccentColor {
  fill: var(--sapIllus_AccentColor);
}
.sapIllus_NoColor {
  fill: var(--sapIllus_NoColor);
}
.sapIllus_PatternShadow {
  fill: var(--sapIllus_PatternShadow);
}
.sapIllus_PatternHighlight {
  fill: var(--sapIllus_PatternHighlight);
}
/* contents of dist/sapIllus-Layout.css */
:root {
  --sapIllus_CaptionColor: #32363A;
  --sapIllus_CaptionMessageColor: #6A6D70;
}
.sapIllus {
  display: block;
  margin: 0;
  text-align: center;
}
.sapIllus_Image,
.sapIllus_Caption {
  display: block;
  margin: 0 auto;
}
.sapIllus_Caption {
  max-width: 288px;
}
@media screen and (min-width: 600px) {
  .sapIllus_Caption {
    max-width: 400px;
  }
}
.sapIllus_CaptionHeader {
  color: var(--sapIllus_CaptionColor);
  display: block;
  margin-bottom: 4px;
  font-size: 1rem;
  font-weight: normal;
  line-height: 1.25;
}
.sapIllus_CaptionMessage {
  color: var(--sapIllus_CaptionMessageColor);
  font-size: 0.875rem;
  font-weight: normal;
  line-height: 1.428571428571429;
}
.sapIllus_Spot {
  padding: 24px 16px 32px;
}
.sapIllus_Spot .sapIllus_Image {
  width: 128px;
  height: 128px;
  margin-bottom: 8px;
}
.sapIllus_Dialog {
  padding: 32px 16px 48px;
}
.sapIllus_Dialog .sapIllus_Image {
  width: 160px;
  height: 160px;
  margin-bottom: 32px;
}

@media screen and (min-width: 600px) {
  .sapIllus_Dialog .sapIllus_CaptionHeader {
    font-size: 1.125rem;
    line-height: 1.333333333333333;
  }
}
.sapIllus_Scene {
  padding: 0 !important;
}
.sapIllus_Scene .sapIllus_Image {
  width: 240px;
  height: 180px;
  margin-bottom: 32px;
}
.sapIllus_Scene .sapIllus_CaptionHeader {
  margin-bottom: 8px;
  font-size: 1.5rem;
  line-height: 1.333333333333333;
}
.sapIllus_Scene .sapIllus_CaptionMessage {
  font-size: 1.125rem;
  line-height: 1.333333333333333;
}
@media screen and (min-width: 600px) {
  .sapIllus_Scene .sapIllus_Image {
    width: 320px;
    height: 240px;
  }
}

</style>