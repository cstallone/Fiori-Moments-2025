<template>
	<div class="Borderedbox">
	  <b-card>
		<h6><strong>{{ title }}</strong></h6>
	    <b-card-text v-html="description"></b-card-text>
	  </b-card>
	</div>
</template>

<script>
import { BCard, BCardText } from 'bootstrap-vue'; 
Vue.component('b-card', BCard);
import Vue from 'vue';

export default {
	components: {
	    'b-card': BCard,
	    'b-card-text': BCardText
    },
	props: {
		description: {
			type: String,
			default: "Lorem ipsum dolor"
		},
		title: String
	}
}
</script>
<style lang="scss">
.Borderedbox {
  .card {
    background-color: transparent;
    box-shadow: none;
  }
}
  </style>