<template>
<div role="tablist" class="accordion accordion-boxed">
    <b-card no-body class="mb-1">
      <b-card-header role="tab" >
        <b-button block v-b-toggle="accordionId" variant="link">{{ this.title }}</b-button>
      </b-card-header>
      <b-collapse v-bind:id="accordionId" accordion="my-accordion" role="tabpanel">
        <b-card-body>
          <b-card-text>
            <div class="library-example">
              <b-card no-body>
                <b-tabs pills card>
                  <b-tab title="Illustration" active>
                    <b-card-text>
                    <!-- All tab starts here -->
                        <tabs
                          :tabs="tabs"
                          :currentTab="currentTab"
                          :wrapper-class="'default-tabs'"
                          :tab-class="'default-tabs__item'"
                          :tab-active-class="'default-tabs__item_active'"
                          :line-class="'default-tabs__active-line'"
                          @onClick="handleClick"
                        />
                        <div class="content mt-4">
                          <!-- <div class="mt-3">Selected: <strong>{{ selected1 }}</strong></div> -->
                          <!-- Spot Tab Starts here -->
                          <div v-if="(currentTab === 'tab1') && (selected1 === 'Spot 1')">
                            <client-only><div v-html="nospotsvg"></div></client-only> <!-- when there is no Spot illustration -->
                            <!-- For 2 Options in Select DP -->
                            <div class="dropdown" v-bind:class="nospotsvgcss" v-if="DropDown === '2'">Option:
                              <label>
                                  <select v-model="selected1" ref="selected1" v-bind:class="isOptionDisabled" :disabled="this.isOptionDisabled">
                                    <option :selected="option == 'Spot 1'" v-for="option in SpotTwoOptions">{{option}}</option>
                                  </select>
                              </label>
                            </div>
                            <!-- For 3 Options in Select DropDown -->
                            <div class="dropdown" v-bind:class="nospotsvgcss" v-if="DropDown === '3'">Option:
                              <label>
                                <select v-model="selected1" v-bind:class="isOptionDisabled" :disabled="this.isOptionDisabled">
                                  <option v-for="option in SpotThreeOptions">{{option}}</option>
                                </select>
                              </label>
                            </div>
                            <div style="clear:both"></div>
                              <Moment :type="this.type" v-bind:id="this.id" v-bind:header="this.header" v-bind:message="this.message" v-bind:class="nospotsvgcss"/>
                                  <div class="app" v-bind:class="nospotsvgcss"> <!--Show/Hide Button starts here-->
                                      <a v-on:click="isHidden = !isHidden">{{ isHidden ? 'See Code' : 'Hide Code' }}</a>
                                        <b-card-text v-if="!isHidden">
                                          <pre class="language-markup"><code>
                                              &lt;figure class="sapIllus sapIllus_{{ uppercaseType }}"&gt;
                                                &lt;svg class="sapIllus_Image" role="img"&gt;
                                                  &lt;use xlink:href="#sapIllus-{{uppercaseType}}-{{this.id}}"&gt;&lt;/use&gt;
                                                &lt;/svg&gt;
                                                &lt;figcaption class="sapIllus_Caption"&gt;
                                                  &lt;h3 class="sapIllus_CaptionHeader"&gt;{{ this.header }}&lt;/h3&gt;
                                                  &lt;p class="sapIllus_CaptionMessage"&gt;{{ this.message }}&lt;/p&gt;
                                                &lt;/figcaption&gt;
                                              &lt;/figure&gt;
                                            </code></pre>
                                        </b-card-text>
                                  </div>
                          </div>
                          <div v-if="(currentTab === 'tab1') && (selected1 === 'Spot 2')">
                            <!-- For 2 Options in Select DP -->
                            <div class="dropdown" v-bind:class="nospotsvgcss" v-if="DropDown === '2'">Option:
                              <label>
                                <select v-model="selected1" ref="selected1">
                                  <option v-for="option in SpotTwoOptions">{{option}}</option>
                                </select>
                              </label>
                            </div> 
                            <!-- For 3 Options in Select DropDown -->
                            <div class="dropdown" v-bind:class="nospotsvgcss" v-if="DropDown === '3'">Option:
                              <label>
                                <select v-model="selected1" ref="selected1">
                                  <option v-for="option in SpotThreeOptions">{{option}}</option>
                                </select>
                              </label>
                            </div>
                            <div style="clear:both"></div>
                              <Moment2 :type="this.type" :id="this.id" :header="this.headerSpot" :message="this.messageSpot"/>
                                  <div class="app"> <!--Show/Hide Button starts here-->
                                      <a v-on:click="isHidden = !isHidden">{{ isHidden ? 'See Code' : 'Hide Code' }}</a>
                                        <b-card-text v-if="!isHidden">
                                          <pre class="language-markup"><code>
                                              &lt;figure class="sapIllus sapIllus_{{ uppercaseType }}"&gt;
                                                &lt;svg class="sapIllus_Image" role="img"&gt;
                                                  &lt;use xlink:href="#sapIllus-{{uppercaseType}}-{{this.id}}-Alt"&gt;&lt;/use&gt;
                                                &lt;/svg&gt;
                                                &lt;figcaption class="sapIllus_Caption"&gt;
                                                  &lt;h3 class="sapIllus_CaptionHeader"&gt;{{ this.headerSpot }}&lt;/h3&gt;
                                                  &lt;p class="sapIllus_CaptionMessage"&gt;{{ this.messageSpot }}&lt;/p&gt;
                                                &lt;/figcaption&gt;
                                              &lt;/figure&gt;
                                            </code></pre>
                                        </b-card-text>
                                  </div>
                          </div>
                          <div v-if="(currentTab === 'tab1') && (selected1 === 'Spot 3')">
                            <!-- For 2 Options in Select DP -->
                            <div class="dropdown" v-bind:class="nospotsvgcss" v-if="DropDown === '2'">Option:
                              <label>
                                <select v-model="selected1" ref="selected1">
                                  <option v-for="option in SpotTwoOptions">{{option}}</option>
                                </select>
                              </label>
                            </div>
                            <!-- For 3 Options in Select DropDown -->
                            <div class="dropdown" v-bind:class="nospotsvgcss" v-if="DropDown === '3'">Option:
                              <label>
                                <select v-model="selected1" ref="selected1">
                                  <option v-for="option in SpotThreeOptions">{{option}}</option>
                                </select>
                              </label>
                            </div>
                            <div style="clear:both"></div>
                              <Moment3 :type="this.type" :id="this.id" :header="this.headerSpot3" :message="this.messageSpot3"/>
                                  <div class="app"> <!--Show/Hide Button starts here-->
                                      <a v-on:click="isHidden = !isHidden">{{ isHidden ? 'See Code' : 'Hide Code' }}</a>
                                        <b-card-text v-if="!isHidden">
                                          <pre class="language-markup"><code>
                                              &lt;figure class="sapIllus sapIllus_{{ uppercaseType }}"&gt;
                                                &lt;svg class="sapIllus_Image" role="img"&gt;
                                                  &lt;use xlink:href="#sapIllus-{{uppercaseType}}-{{this.id}}-Alt2"&gt;&lt;/use&gt;
                                                &lt;/svg&gt;
                                                &lt;figcaption class="sapIllus_Caption"&gt;
                                                  &lt;h3 class="sapIllus_CaptionHeader"&gt;{{ this.headerSpot3 }}&lt;/h3&gt;
                                                  &lt;p class="sapIllus_CaptionMessage"&gt;{{ this.messageSpot3 }}&lt;/p&gt;
                                                &lt;/figcaption&gt;
                                              &lt;/figure&gt;
                                            </code></pre>
                                        </b-card-text>
                                  </div>
                          </div>
                          <!-- Dialog Tab Starts here -->
                          <div v-if="(currentTab === 'tab2') && (selected2 === 'Dialog 1')">
                            <client-only><div v-html="nodialogsvg"></div></client-only> <!-- when there is no Scene illustration -->
                            <!-- For 2 Options in Dialog1 Select Dropdown -->
                            <div class="dropdown" v-bind:class="nodialogcss" v-if="DropDown === '2'">Option:
                              <label>
                                <select v-model="selected2" :disabled="this.dialogOptionDisabled" v-bind:class="dialogOptionDisabled">
                                  <option v-for="option in DialogTwoOptions">{{option}}</option>
                                </select>
                              </label>
                            </div>
                            <!-- For 3 Options in Dialog1 Select DropDown -->
                            <div class="dropdown" v-bind:class="nodialogcss" v-if="DropDown === '3'">Option:
                              <label>
                                <select v-model="selected2" :disabled="this.dialogOptionDisabled" v-bind:class="dialogOptionDisabled">
                                  <option v-for="option in DialogThreeOptions">{{option}}</option>
                                </select>
                              </label>
                            </div>
                            <div style="clear:both"></div>
                            <Moment :type="this.typeDialog" :id="this.idDialog" :header="this.headerDialog1" :message="this.messageDialog1" v-bind:class="nodialogcss"/>
                                <div class="app" v-bind:class="nodialogcss"> <!--Show/Hide button starts here-->
                                    <a v-on:click="isHidden = !isHidden">{{ isHidden ? 'See Code' : 'Hide Code' }}</a>
                                      <b-card-text v-if="!isHidden">
                                        <pre class="language-markup"><code>
                                            &lt;figure class="sapIllus sapIllus_{{ uppercaseTypeDialog }}"&gt;
                                              &lt;svg class="sapIllus_Image" role="img"&gt;
                                                &lt;use xlink:href="#sapIllus-{{uppercaseTypeDialog}}-{{this.idDialog}}"&gt;&lt;/use&gt;
                                              &lt;/svg&gt;
                                              &lt;figcaption class="sapIllus_Caption"&gt;
                                                &lt;h3 class="sapIllus_CaptionHeader"&gt;{{ this.headerDialog1 }}&lt;/h3&gt;
                                                &lt;p class="sapIllus_CaptionMessage"&gt;{{ this.messageDialog1 }}&lt;/p&gt;
                                              &lt;/figcaption&gt;
                                            &lt;/figure&gt;
                                          </code></pre>
                                      </b-card-text>
                                </div>
                          </div>
                          <div v-if="(currentTab === 'tab2') && (selected2 === 'Dialog 2')">
                            <!-- For 2 Options in Dialog2 Select DropDown -->
                            <div class="dropdown" v-bind:class="nodialogcss" v-if="DropDown === '2'">Option:
                              <label>
                                <select v-model="selected2">
                                  <option v-for="option in DialogTwoOptions">{{option}}</option>
                                </select>
                              </label>
                            </div>
                            <!-- For 3 Options in Dialog2 Select DropDown -->
                            <div class="dropdown" v-bind:class="nodialogcss" v-if="DropDown === '3'">Option:
                              <label>
                                <select v-model="selected2">
                                  <option v-for="option in DialogThreeOptions">{{option}}</option>
                                </select>
                              </label>
                            </div>
                            <div style="clear:both"></div>
                            <Moment2 :type="this.typeDialog" v-bind:id="this.idDialog" v-bind:header="this.headerDialog2" v-bind:message="this.messageDialog2"/>
                                <div class="app"> <!--Show/Hide button starts here-->
                                    <a v-on:click="isHidden = !isHidden">{{ isHidden ? 'See Code' : 'Hide Code' }}</a>
                                      <b-card-text v-if="!isHidden">
                                        <pre class="language-markup"><code>
                                            &lt;figure class="sapIllus sapIllus_{{ uppercaseTypeDialog }}"&gt;
                                              &lt;svg class="sapIllus_Image" role="img"&gt;
                                                &lt;use xlink:href="#sapIllus-{{uppercaseTypeDialog }}-{{this.idDialog}}-Alt"&gt;&lt;/use&gt;
                                              &lt;/svg&gt;
                                              &lt;figcaption class="sapIllus_Caption"&gt;
                                                &lt;h3 class="sapIllus_CaptionHeader"&gt;{{ this.headerDialog2 }}&lt;/h3&gt;
                                                &lt;p class="sapIllus_CaptionMessage"&gt;{{ this.messageDialog2 }}&lt;/p&gt;
                                              &lt;/figcaption&gt;
                                            &lt;/figure&gt;
                                          </code></pre>
                                      </b-card-text>
                                </div>
                          </div>   
                          <div v-if="(currentTab === 'tab2') && (selected2 === 'Dialog 3')">
                            <!-- For 2 Options in Dialog3 Select DP -->
                            <div class="dropdown" v-bind:class="nodialogcss" v-if="DropDown === '2'">Option:
                              <label>
                                <select v-model="selected2">
                                  <option v-for="option in DialogTwoOptions">{{option}}</option>
                                </select>
                              </label>
                            </div>
                            <!-- For 3 Options in Dialog3 Select DropDown -->
                            <div class="dropdown" v-bind:class="nodialogcss" v-if="DropDown === '3'">Option:
                              <label>
                                <select v-model="selected2">
                                  <option v-for="option in DialogThreeOptions">{{option}}</option>
                                </select>
                              </label>
                            </div>
                            <div style="clear:both"></div>
                            <Moment3 :type="this.typeDialog" :id="this.idDialog" :header="this.headerDialog3" :message="this.messageDialog3"/>
                                <div class="app"> <!--Show/Hide button starts here-->
                                    <a v-on:click="isHidden = !isHidden">{{ isHidden ? 'See Code' : 'Hide Code' }}</a>
                                      <b-card-text v-if="!isHidden">
                                        <pre class="language-markup"><code>
                                            &lt;figure class="sapIllus sapIllus_{{ uppercaseTypeDialog }}"&gt;
                                              &lt;svg class="sapIllus_Image" role="img"&gt;
                                                &lt;use xlink:href="#sapIllus-{{uppercaseTypeDialog }}-{{this.idDialog}}-Alt2"&gt;&lt;/use&gt;
                                              &lt;/svg&gt;
                                              &lt;figcaption class="sapIllus_Caption"&gt;
                                                &lt;h3 class="sapIllus_CaptionHeader"&gt;{{ this.headerDialog3 }}&lt;/h3&gt;
                                                &lt;p class="sapIllus_CaptionMessage"&gt;{{ this.messageDialog3 }}&lt;/p&gt;
                                              &lt;/figcaption&gt;
                                            &lt;/figure&gt;
                                          </code></pre>
                                      </b-card-text>
                                </div>
                          </div>

                          <!-- Scene Tab Starts here -->
                          <div v-if="(currentTab === 'tab3') && (selected3 === 'Scene 1') ">
                            <client-only><div v-html="noscenesvg"></div></client-only> <!-- when there is no Dialog illustration -->
                            <!-- For 2 Options in Scene1 Select DP -->
                            <div class="dropdown" v-bind:class="noscenecss" v-if="DropDown === '2'">Option:
                              <label>
                                <select v-model="selected3" :disabled="this.sceneOptionDisabled" v-bind:class="sceneOptionDisabled">
                                    <option v-for="option in SceneTwoOptions">{{option}}</option>
                                  </select>
                              </label>
                            </div>
                            <!-- For 3 Options in Scene1 Select DropDown -->
                            <div class="dropdown" v-bind:class="noscenecss" v-if="DropDown === '3'">Option:
                                <label>
                                  <select v-model="selected3" :disabled="this.sceneOptionDisabled" v-bind:class="sceneOptionDisabled">
                                      <option v-for="option in SceneThreeOptions">{{option}}</option>
                                    </select>
                                </label>
                            </div>
                            <div style="clear:both"></div>
                             <Moment :type="this.typeScene" :id="this.idScene" :header="this.headerScene1" :message="this.messageScene1" v-bind:class="noscenecss"/>
                                <div class="app" v-bind:class="noscenecss"> <!--Show/Hide button starts here-->
                                    <a v-on:click="isHidden = !isHidden">{{ isHidden ? 'See Code' : 'Hide Code' }}</a>
                                      <b-card-text v-if="!isHidden">
                                        <pre class="language-markup"><code>
                                            &lt;figure class="sapIllus sapIllus_{{ uppercaseTypeScene }}"&gt;
                                              &lt;svg class="sapIllus_Image" role="img"&gt;
                                                &lt;use xlink:href="#sapIllus-{{uppercaseTypeScene }}-{{this.idScene}}"&gt;&lt;/use&gt;
                                              &lt;/svg&gt;
                                              &lt;figcaption class="sapIllus_Caption"&gt;
                                                &lt;h3 class="sapIllus_CaptionHeader"&gt;{{ this.headerScene1 }}&lt;/h3&gt;
                                                &lt;p class="sapIllus_CaptionMessage"&gt;{{ this.messageScene1 }}&lt;/p&gt;
                                              &lt;/figcaption&gt;
                                            &lt;/figure&gt;
                                          </code></pre>
                                      </b-card-text>
                                </div>
                          </div>
                          <div v-if="(currentTab === 'tab3') && (selected3 === 'Scene 2') ">
                            <!-- For 2 Options in Scene2 Select DP -->
                            <div class="dropdown" v-bind:class="noscenecss" v-if="DropDown === '2'">Option:
                              <label>
                                <select v-model="selected3">
                                    <option v-for="option in SceneTwoOptions">{{option}}</option>
                                  </select>
                              </label>
                            </div>
                            <!-- For 3 Options in Scene2 Select DropDown -->
                            <div class="dropdown" v-bind:class="noscenecss" v-if="DropDown === '3'">Option:
                              <label>
                                <select v-model="selected3">
                                    <option v-for="option in SceneThreeOptions">{{option}}</option>
                                  </select>
                              </label>
                            </div>
                            <div style="clear:both"></div>
                             <Moment2 :type="this.typeScene" :id="this.idScene" :header="this.headerScene2" :message="this.messageScene2"/>
                                <div class="app"> <!--Show/Hide button starts here-->
                                    <a v-on:click="isHidden = !isHidden">{{ isHidden ? 'See Code' : 'Hide Code' }}</a>
                                      <b-card-text v-if="!isHidden">
                                        <pre class="language-markup"><code>
                                           &lt;figure class="sapIllus sapIllus_{{ uppercaseTypeScene }}"&gt;
                                              &lt;svg class="sapIllus_Image" role="img"&gt;
                                                &lt;use xlink:href="#sapIllus-{{uppercaseTypeScene}}-{{this.idScene}}-Alt"&gt;&lt;/use&gt;
                                              &lt;/svg&gt;
                                              &lt;figcaption class="sapIllus_Caption"&gt;
                                                &lt;h3 class="sapIllus_CaptionHeader"&gt;{{ this.headerScene2 }}&lt;/h3&gt;
                                                &lt;p class="sapIllus_CaptionMessage"&gt;{{ this.messageScene2 }}&lt;/p&gt;
                                              &lt;/figcaption&gt;
                                            &lt;/figure&gt;
                                          </code></pre>
                                      </b-card-text>
                                </div>
                          </div>
                          <div v-if="(currentTab === 'tab3') && (selected3 === 'Scene 3')">
                            <!-- For 2 Options in Select DP -->
                            <div class="dropdown" v-bind:class="noscenecss" v-if="DropDown === '2'">Option:
                              <label>
                                <select v-model="selected3">
                                    <option v-for="option in SceneTwoOptions">{{option}}</option>
                                  </select>
                              </label>
                            </div>
                            <!-- For 3 Options in Select DropDown -->
                            <div class="dropdown" v-bind:class="noscenecss" v-if="DropDown === '3'">Option:
                              <label>
                                <select v-model="selected3">
                                    <option v-for="option in SceneThreeOptions">{{option}}</option>
                                  </select>
                              </label>
                            </div>
                            <div style="clear:both"></div>
                             <Moment3 :type="this.typeScene" :id="this.idScene" :header="this.headerScene3" :message="this.messageScene3"/>
                                <div class="app"> <!--Show/Hide button starts here-->
                                    <a v-on:click="isHidden = !isHidden">{{ isHidden ? 'See Code' : 'Hide Code' }}</a>
                                      <b-card-text v-if="!isHidden">
                                        <pre class="language-markup"><code>
                                            &lt;figure class="sapIllus sapIllus_{{ uppercaseTypeScene }}"&gt;
                                              &lt;svg class="sapIllus_Image" role="img"&gt;
                                                &lt;use xlink:href="#sapIllus-{{uppercaseTypeScene}}-{{this.idScene}}-Alt2"&gt;&lt;/use&gt;
                                              &lt;/svg&gt;
                                              &lt;figcaption class="sapIllus_Caption"&gt;
                                                &lt;h3 class="sapIllus_CaptionHeader"&gt;{{ this.headerScene3 }}&lt;/h3&gt;
                                                &lt;p class="sapIllus_CaptionMessage"&gt;{{ this.messageScene3 }}&lt;/p&gt;
                                              &lt;/figcaption&gt;
                                            &lt;/figure&gt;
                                          </code></pre>
                                      </b-card-text>
                                </div>
                          </div>
                        </div>
                    </b-card-text>
                  </b-tab>
                  <b-tab title="Message">
                    <client-only><b-card-text v-html="description"></b-card-text></client-only>
                  </b-tab>
                </b-tabs>
              </b-card>
            </div>
          </b-card-text>
        </b-card-body>
      </b-collapse>
    </b-card>
</div>
</template>


<script>
import { BCard, BCardText, BTabs, BTab, BButton, CollapsePlugin,CardPlugin, BFormSelect, FormSelectPlugin, BDropdown, DropdownPlugin } from 'bootstrap-vue'; 
import Vue from 'vue';
import Tabs from 'vue-tabs-with-active-line';
Vue.use(CollapsePlugin);
Vue.use(CardPlugin);

export default {
  components: {
    'b-card': BCard,
    'b-tabs': BTabs,
    'b-tab': BTab,
    'b-card-text': BCardText,
    'tabs': Tabs,
    'b-button': BButton,
    'b-dropdown': BDropdown,
    'b-form-select': BFormSelect
  },
  props: {
    options: {
      type: Array,
      default() {
        return [];
      }
    },
    disabled: {
      type: Boolean,
      default: false
    },
    id: String,
    accordionId: String,
    title: String,
    type: String,
    idDialog: String,
    typeDialog: String,
    typeSpot: String,
    idSpot: String,
    typeScene: String,
    idScene: String,
    titletext: String,
    description: String,
    nospotsvg: String,
    noscenesvg: String,
    nodialogsvg: String,
    nosvg: String,
    nospotsvgcss: String,
    noscenecss: String,
    nodialogcss: String,
    message: String,
    header: String,
    isOptionDisabled: String,
    dialogOptionDisabled: String,
    sceneOptionDisabled: String,
    DropDown: String,
    messageSpot: String,
    headerSpot: String,
    headerSpot3: String,
    messageSpot3: String,
    headerDialog1: {
      type: String,
      default: ""
    },
    headerDialog2: {
      type: String,
      default: ""
    },
    headerDialog3: {
      type: String,
      default: ""
    },
    messageDialog1: {
      type: String,
      default: ""
    },
    messageDialog2: {
      type: String,
      default: ""
    },
    messageDialog3: {
      type: String,
      default: ""
    },
    headerScene1: {
      type: String,
      default: ""
    },
    headerScene2: {
      type: String,
      default: ""
    },
    headerScene3: {
      type: String,
      default: ""
    },
    messageScene1: {
      type: String,
      default: ""
    },
    messageScene2: {
      type: String,
      default: ""
    },
    messageScene3: {
      type: String,
      default: ""
    }
  },
  computed: {
    uppercaseType() {
      return this.type.charAt(0).toUpperCase() + this.type.slice(1);
    },
    uppercaseTypeDialog(){
      return this.typeDialog.charAt(0).toUpperCase() + this.typeDialog.slice(1);
    },
    uppercaseTypeScene(){
      return this.typeScene.charAt(0).toUpperCase() + this.typeScene.slice(1);
    }
    
  },
  name: 'app',
   data: () => ({
    tabs: [
      { title: 'Spot', value: 'tab1' },
      { title: 'Dialog', value: 'tab2' },
      { title: 'Scene', value: 'tab3', }
    ],
    currentTab: 'tab1',
    isHidden: true,
    visible: false,
    index: 1,
    placement:'down',
    SpotTwoOptions: ['Spot 1', 'Spot 2'],
    selected1: 'Spot 1',
    DialogTwoOptions: ['Dialog 1', 'Dialog 2'],
    selected2: 'Dialog 1',
    SceneTwoOptions: ['Scene 1', 'Scene 2' ],
    selected3: 'Scene 1',
    SpotThreeOptions: ['Spot 1', 'Spot 2', 'Spot 3'],
    DialogThreeOptions: ['Dialog 1', 'Dialog 2', 'Dialog 3'],
    SceneThreeOptions: ['Scene 1', 'Scene 2', 'Scene 3'],
    
  }),
   methods: {
    handleClick(newTab) {
      this.currentTab = newTab;
     // console.log('this component is showing')
    }
  }
}

</script>
<style lang="scss">
.library-example {
  margin-top: 12px;
  .card {
    background-color: transparent;
    box-shadow: none;
    border:0;
  }
  .card:hover{
    text-decoration: none;
  }
  .card-header {
    padding: 0;
    background-color: transparent;
    border: none;
    margin-bottom: 24px;
  }
  .card-header-pills {
    margin-top: 0;
  }
  .card-body {
    background: rgb(255, 255, 255);
    padding-left: 0;
  }
  .nav-link {
    text-transform: capitalize;
    font-weight: normal;
    &.active {
      background-color: white;
    }
  }
  .app a {
    cursor: pointer;
    color: rgb(10, 110, 209);
    margin-bottom: 10px;
    font-size: 14px;
    display: block;
    margin-left: 10px;
  }
  .app a:hover {
    cursor: pointer;
    color: rgb(10, 110, 209);
    text-decoration: underline;
  }
  .language-markup{
    background: rgb(229, 229, 229);
    box-shadow: 0px 0px 15px 0px rgba(0, 0, 0, 0.05);
    border: 1px solid #e5e5e5;
    border-radius: 0.25rem;
    white-space: pre-line;
    padding: 20px !important;
  }
  .border-left{
    padding-left: 20px;
    margin-top: 20px
  }
  .custom-select {
   width:20%;
   height: 50px;
   width:110px;
  }
  .dropdown {
    margin-top: 20px;
    font-size: 16px;
    float: right;
  }
  .select{
    width:100px;
    height: 45px;
    line-height:35px;
  }
  .dropMenu{
    min-width: 100px
  }
  .dropMenu li {
    height: 35px;
    padding: 10px;
    border-top: 2px solid #f8f8f8;
  }
  .down.input-control{
  border-top: none;
  }
}
  .disabled{ 
    position : relative; 
    color: #999;
    border:1px solid #999;
  }
 .disabled:after {
    content:' ';
    width: 100%;
    height: 100%;
    left:0;
    top: 0;
    position:absolute;
  }
  .disabled .input-control input {
    color: #B8B8B8
  }
  .disabled .down.input-control[data-v-4ab04475]::after {
    border-top: 8px solid #E8E8E8;
  }
  .nospotsvg, .nodialogsvg, .noscenesvg {
    display: none;
  }
  .accordion-boxed .card .card-header button {
    text-decoration: none !important;
  }
  ul {
  padding-left: 20px;
  margin:0
  }
  
/*Styles for 3 tabs */
.default-tabs {
  position: relative;
  margin: 0 auto;
  border-bottom: 1px solid #e5e5e5;
  &__item {
    display: inline-block;
    margin: 0 5px;
    padding: 10px;
    padding-bottom: 8px;
    font-size: 16px;
    letter-spacing: 0.8px;
    color: gray;
    text-decoration: none;
    border: none;
    background-color: transparent;
    cursor: pointer;
    &_active {
      border-bottom: 2px solid rgb(38, 76, 220) !important;
    }
    &:hover {
      border-bottom: 2px solid gray;
    }
    &:focus {
      outline: none;
      border-bottom: 2px solid gray;
    }
    &:first-child {
      margin-left: 0;
    }
    &:last-child {
      margin-right: 0;
    }
  }
  &__active-line {
    position: absolute;
    bottom: 0;
    left: 0;
    height: 2px;
    transition: transform 0.4s ease, width 0.4s ease;
    background: transparent;
  }
}
@media (max-width: 991.98px){
.navbar-nav {
    margin-top: 0px;
}
}

/* Select dropdown styling */
select {
    padding:3px 3px 3px 9px;
    margin: 0;
    -webkit-border-radius:4px;
    -moz-border-radius:4px;
    border-radius:4px;
    background: #fff;
    color:#696969;
    border:1px solid #808080;
    outline:none;
    display: inline-block;
    -webkit-appearance:none;
    -moz-appearance:none;
    appearance:none;
    cursor:pointer;
}

/* Targetting Webkit browsers only. FF will show the dropdown arrow with so much padding. */
@media screen and (-webkit-min-device-pixel-ratio:0) {
    select {padding-right:35px}
}

label {position:relative}
label:after {
    content:'\25bc';
    font:15px "Consolas", monospace;
    color:#aaa;
    right: 14px; 
    top: 7px;
    padding:0 0 2px;
    position:absolute;
    pointer-events:none;
}
label:before {
    content:'';
    right:6px; top:0px;
    width:20px; height:20px;
    background: none;
    position:absolute;
    pointer-events:none;
    display:block;
    }
</style>